import { Router, type IRouter } from "express";
import { StartScanBody, StartScanResponse } from "@workspace/api-zod";
import { scanParameter, DETECTION_PAYLOADS, worstSeverity } from "../lib/scanner";

const router: IRouter = Router();

router.post("/scan", async (req, res): Promise<void> => {
  const parsed = StartScanBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { url, timeout } = parsed.data;
  const timeoutMs = timeout ?? 8000;

  let targetUrl: URL;
  try {
    targetUrl = new URL(url);
  } catch {
    res.status(400).json({ error: "Invalid URL format. Include http:// or https://" });
    return;
  }

  if (!["http:", "https:"].includes(targetUrl.protocol)) {
    res.status(400).json({ error: "Only HTTP and HTTPS URLs are supported" });
    return;
  }

  const params = [...targetUrl.searchParams.entries()];

  if (params.length === 0) {
    res.json(
      StartScanResponse.parse({
        target: url,
        scanDuration: 0,
        parameters: [],
        summary: {
          totalParams: 0,
          vulnerableParams: 0,
          safeParams: 0,
          totalPayloadsTested: 0,
          totalHits: 0,
        },
      })
    );
    return;
  }

  const startTime = Date.now();
  req.log.info({ target: url, paramCount: params.length }, "Starting XSS scan");

  const paramResults = [];
  for (const [paramName, originalValue] of params) {
    const result = await scanParameter(targetUrl, paramName, originalValue, timeoutMs);
    paramResults.push({
      name: result.name,
      originalValue: result.originalValue,
      vulnerable: result.vulnerable,
      severity: result.severity,
      totalTested: result.totalTested,
      payloadsHit: result.payloadsHit.map((h) => ({
        payload: h.payload,
        reflectionType: h.reflectionType,
        evidence: h.evidence,
      })),
    });
  }

  const scanDuration = Date.now() - startTime;
  const vulnerableParams = paramResults.filter((p) => p.vulnerable).length;
  const totalHits = paramResults.reduce((s, p) => s + p.payloadsHit.length, 0);

  res.json(
    StartScanResponse.parse({
      target: url,
      scanDuration,
      parameters: paramResults,
      summary: {
        totalParams: params.length,
        vulnerableParams,
        safeParams: params.length - vulnerableParams,
        totalPayloadsTested: params.length * DETECTION_PAYLOADS.length,
        totalHits,
      },
    })
  );
});

export default router;
