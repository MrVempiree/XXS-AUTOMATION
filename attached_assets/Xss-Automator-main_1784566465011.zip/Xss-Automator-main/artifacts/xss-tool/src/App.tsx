import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { Code2, Search, Shield, Zap, Target, Settings, Database, Activity } from 'lucide-react';
import Library from './pages/Library';
import Generator from './pages/Generator';
import Encoder from './pages/Encoder';
import Fuzzer from './pages/Fuzzer';
import Scanner from './pages/Scanner';
import SQLi from './pages/SQLi';
import Admin from './pages/Admin';
import LicenseGate, { useLicense, clearLicense } from './components/LicenseGate';

const queryClient = new QueryClient();

function Sidebar() {
  const [location, setLocation] = useLocation();
  const license = useLicense();

  const xssItems = [
    { href: '/',          icon: Search,   label: 'Payload Library' },
    { href: '/generator', icon: Zap,      label: 'Generator' },
    { href: '/encoder',   icon: Code2,    label: 'Encoder' },
    { href: '/scanner',   icon: Target,   label: 'XSS Scanner' },
    { href: '/fuzzer',    icon: Shield,   label: 'Fuzzer' },
  ];

  const sqliItems = [
    { href: '/sqli', icon: Database, label: 'SQLi Scanner' },
  ];

  const NavBtn = ({ href, icon: Icon, label }: { href: string; icon: typeof Target; label: string }) => {
    const isActive = location === href;
    return (
      <button
        onClick={() => setLocation(href)}
        className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-semibold transition-all duration-150 ${
          isActive
            ? 'bg-primary/10 text-primary border border-primary/20 shadow-[inset_2px_0_0_0_hsl(var(--primary))]'
            : 'text-muted-foreground hover:bg-secondary hover:text-foreground border border-transparent'
        }`}
      >
        <Icon className={`w-4 h-4 ${isActive ? 'text-primary' : 'opacity-60'}`} />
        {label}
      </button>
    );
  };

  return (
    <div className="w-60 border-r border-border bg-card h-screen flex flex-col shrink-0 selection:bg-primary/30">
      {/* Brand */}
      <div className="px-4 py-4 border-b border-border">
        <div className="flex items-center gap-2.5 mb-0.5">
          <Activity className="w-5 h-5 text-primary shrink-0" />
          <h1 className="font-brand text-[15px] font-black leading-none text-primary tracking-wide">
            ALCAME
          </h1>
        </div>
        <div className="font-brand text-[10px] font-bold text-muted-foreground tracking-[0.22em] ml-7">
          AUTOMATION
        </div>
        <div className="text-[9px] font-mono-hack text-primary/50 uppercase tracking-widest mt-1.5 ml-7">
          Security Research Toolkit
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-4 overflow-y-auto">
        {/* XSS section */}
        <div>
          <div className="text-[9px] font-black uppercase tracking-[0.2em] text-muted-foreground/50 px-3 mb-1.5">
            XSS MODULE
          </div>
          <div className="space-y-0.5">
            {xssItems.map(item => <NavBtn key={item.href} {...item} />)}
          </div>
        </div>

        {/* SQLi section */}
        <div>
          <div className="text-[9px] font-black uppercase tracking-[0.2em] text-muted-foreground/50 px-3 mb-1.5">
            SQL INJECTION
          </div>
          <div className="space-y-0.5">
            {sqliItems.map(item => <NavBtn key={item.href} {...item} />)}
          </div>
        </div>
      </nav>

      <div className="p-3 border-t border-border bg-secondary/20 space-y-2">
        {license && (
          <div className="flex items-center justify-between px-2 py-1.5 rounded-md bg-primary/5 border border-primary/15">
            <div className="text-[10px] font-mono text-primary uppercase tracking-wider">
              {license.plan} · {license.owner}
            </div>
            <button onClick={clearLicense} title="Deactivate license" className="text-muted-foreground/40 hover:text-muted-foreground">
              <Settings className="w-3 h-3" />
            </button>
          </div>
        )}
        <div className="text-[10px] text-muted-foreground font-mono flex items-center justify-between">
          <span>v2.0.0</span>
          <span className="text-primary flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            Online
          </span>
        </div>
      </div>
    </div>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen w-full bg-background overflow-hidden dark text-foreground">
      <Sidebar />
      <main className="flex-1 h-screen overflow-hidden flex flex-col bg-background">
        {children}
      </main>
    </div>
  );
}

function AppRouter() {
  return (
    <Switch>
      <Route path="/"          component={Library} />
      <Route path="/generator" component={Generator} />
      <Route path="/encoder"   component={Encoder} />
      <Route path="/scanner"   component={Scanner} />
      <Route path="/fuzzer"    component={Fuzzer} />
      <Route path="/sqli"      component={SQLi} />
      <Route>
        <div className="p-8 text-destructive font-mono h-full flex items-center justify-center text-lg uppercase tracking-widest">
          404 — Module Not Found
        </div>
      </Route>
    </Switch>
  );
}

const TOASTER_OPTS = {
  style: {
    background: 'hsl(var(--card))',
    border:     '1px solid hsl(var(--primary) / 0.4)',
    color:      'hsl(var(--foreground))',
  },
};

function App() {
  const base = import.meta.env.BASE_URL.replace(/\/$/, '');
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={base}>
          <Route path="/admin">{() => <Admin />}</Route>
          <Route>
            {() => (
              <LicenseGate>
                <Layout>
                  <AppRouter />
                </Layout>
              </LicenseGate>
            )}
          </Route>
        </WouterRouter>
        <Toaster theme="dark" position="bottom-right" toastOptions={TOASTER_OPTS} />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
